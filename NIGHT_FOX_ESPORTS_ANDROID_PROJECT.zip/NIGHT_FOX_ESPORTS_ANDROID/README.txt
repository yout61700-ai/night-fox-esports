NIGHT FOX ESPORTS — Android APK project

This Android Studio project wraps the existing NIGHT_FOX_ESPORTS_FINAL.html in a native Android WebView. The HTML/CSS design and black-purple neon look are preserved.

BUILD AN APK
1. Install Android Studio on a computer.
2. Extract NIGHT_FOX_ESPORTS_ANDROID_PROJECT.zip.
3. In Android Studio choose Open and select the extracted NIGHT_FOX_ESPORTS_ANDROID folder.
4. Let Android Studio download the required Android Gradle Plugin/SDK components and sync.
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show the APK location, usually app/build/outputs/apk/debug/app-debug.apk.
7. Copy the APK to your Android phone and install it. You may need to allow installation from that file manager.

IMPORTANT LIMITATIONS
- This project packages the current standalone HTML version. Its localStorage data is stored on this phone/browser app installation and is not shared with other players or devices.
- This is not a server-backed multi-user app. Shared registrations/admin data need a deployed PHP/MySQL backend.
- The existing HTML's admin/password logic is client-side and must not be treated as secure for real admin access.
- This package does not implement or verify real-money payment collection. Use a free-entry tournament flow or a lawful, adult-managed setup for any regulated payment features.
- I could not compile/test the APK in this environment because Android SDK/Gradle build tools are not installed here. This is the Android Studio source project, not a prebuilt APK.
